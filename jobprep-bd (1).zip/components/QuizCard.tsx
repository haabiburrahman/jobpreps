
import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { getAiExplanation } from '../services/geminiService';
import { CheckCircle, XCircle, ChevronRight, MessageSquare, Sparkles } from 'lucide-react';

interface QuizCardProps {
  question: Question;
  onNext: (isCorrect: boolean) => void;
  onFinish: () => void;
  currentIndex: number;
  total: number;
}

const QuizCard: React.FC<QuizCardProps> = ({ question, onNext, onFinish, currentIndex, total }) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    setSelectedIdx(null);
    setShowExplanation(false);
    setAiExplanation(null);
  }, [question]);

  const handleOptionClick = (idx: number) => {
    if (selectedIdx !== null) return;
    setSelectedIdx(idx);
  };

  const isLast = currentIndex === total - 1;

  const getOptionStyles = (idx: number) => {
    if (selectedIdx === null) {
      return "border-gray-200 hover:border-blue-500 hover:bg-blue-50";
    }

    const isCorrect = idx === question.correctAnswerIndex;
    const isSelected = idx === selectedIdx;

    if (isCorrect) {
      return "border-green-500 bg-green-50 ring-2 ring-green-500 text-green-700";
    }
    if (isSelected && !isCorrect) {
      return "border-red-500 bg-red-50 ring-2 ring-red-500 text-red-700";
    }
    return "border-gray-200 opacity-50";
  };

  const handleAiExplain = async () => {
    if (aiExplanation) {
      setShowExplanation(true);
      return;
    }
    setIsAiLoading(true);
    const text = await getAiExplanation(question.questionText, question.options[question.correctAnswerIndex]);
    setAiExplanation(text);
    setShowExplanation(true);
    setIsAiLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6 bg-white rounded-2xl shadow-xl border border-gray-100">
      <div className="flex justify-between items-center mb-6">
        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
          Question {currentIndex + 1} of {total}
        </span>
        <span className="text-gray-400 text-sm font-medium">{question.category} - {question.year}</span>
      </div>

      <h2 className="text-xl md:text-2xl font-semibold text-gray-800 mb-8 leading-relaxed">
        {question.questionText}
      </h2>

      <div className="space-y-4 mb-8">
        {question.options.map((option, idx) => (
          <button
            key={idx}
            disabled={selectedIdx !== null}
            onClick={() => handleOptionClick(idx)}
            className={`w-full p-4 text-left rounded-xl border transition-all duration-200 flex items-center justify-between font-medium ${getOptionStyles(idx)}`}
          >
            <span>{String.fromCharCode(65 + idx)}. {option}</span>
            {selectedIdx !== null && idx === question.correctAnswerIndex && (
              <CheckCircle className="text-green-600 w-5 h-5" />
            )}
            {selectedIdx !== null && idx === selectedIdx && idx !== question.correctAnswerIndex && (
              <XCircle className="text-red-600 w-5 h-5" />
            )}
          </button>
        ))}
      </div>

      {selectedIdx !== null && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex gap-3">
            <button
              onClick={() => setShowExplanation(!showExplanation)}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              {showExplanation ? 'ব্যাখ্যা লুকান' : 'ব্যাখ্যা দেখুন'}
            </button>
            <button
              onClick={handleAiExplain}
              disabled={isAiLoading}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-purple-100 text-purple-700 rounded-xl font-semibold hover:bg-purple-200 transition-colors disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              {isAiLoading ? 'AI ভাবছে...' : 'AI ব্যাখ্যা'}
            </button>
          </div>

          {showExplanation && (
            <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl text-blue-900 text-sm md:text-base leading-relaxed">
              <p className="font-bold mb-1">সঠিক উত্তর ব্যাখ্যা:</p>
              <p className="mb-3">{question.explanation}</p>
              {aiExplanation && (
                <div className="pt-3 border-t border-blue-200">
                  <p className="font-bold mb-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Gemini AI এর বিশ্লেষণ:
                  </p>
                  <p className="italic text-gray-700">{aiExplanation}</p>
                </div>
              )}
            </div>
          )}

          <button
            onClick={() => isLast ? onFinish() : onNext(selectedIdx === question.correctAnswerIndex)}
            className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
          >
            {isLast ? 'ফলাফল দেখুন' : 'পরবর্তী প্রশ্ন'}
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default QuizCard;
