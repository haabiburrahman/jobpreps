
import React, { useState } from 'react';
import { Question, Category } from '../types';
import { CATEGORIES } from '../constants';
import { Plus, Trash2, Save, X, Tags, PlusCircle } from 'lucide-react';

interface AdminPanelProps {
  onAddQuestion: (q: Omit<Question, 'id' | 'createdAt'>) => void;
  onDeleteQuestion: (id: string) => void;
  onAddSubCategory: (category: Category, subCategoryName: string) => void;
  onDeleteSubCategory: (category: Category, subCategoryName: string) => void;
  questions: Question[];
  subCategories: Record<Category, string[]>;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  onAddQuestion, 
  onDeleteQuestion, 
  onAddSubCategory,
  onDeleteSubCategory,
  questions, 
  subCategories 
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [activeTab, setActiveTab] = useState<'QUESTIONS' | 'SUB_CATEGORIES'>('QUESTIONS');
  
  // Question Form State
  const [formData, setFormData] = useState({
    questionText: '',
    options: ['', '', '', ''],
    correctAnswerIndex: 0,
    explanation: '',
    category: 'BCS' as Category,
    subCategory: subCategories['BCS'][0] || '',
    year: '2024'
  });

  // SubCategory Form State
  const [newSubCatName, setNewSubCatName] = useState('');
  const [newSubCatParent, setNewSubCatParent] = useState<Category>('BCS');

  const handleCategoryChange = (cat: Category) => {
    setFormData({
      ...formData,
      category: cat,
      subCategory: subCategories[cat][0] || ''
    });
  };

  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    onAddQuestion(formData);
    setIsAdding(false);
    setFormData({
      questionText: '',
      options: ['', '', '', ''],
      correctAnswerIndex: 0,
      explanation: '',
      category: 'BCS' as Category,
      subCategory: subCategories['BCS'][0] || '',
      year: '2024'
    });
  };

  const handleAddSubCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubCatName.trim()) return;
    onAddSubCategory(newSubCatParent, newSubCatName.trim());
    setNewSubCatName('');
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8 animate-in fade-in duration-300">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-black text-gray-800 tracking-tight">অ্যাডমিন প্যানেল</h2>
        
        <div className="flex bg-gray-100 p-1 rounded-xl w-full md:w-auto">
          <button 
            onClick={() => setActiveTab('QUESTIONS')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'QUESTIONS' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
          >
            প্রশ্নাবলী
          </button>
          <button 
            onClick={() => setActiveTab('SUB_CATEGORIES')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'SUB_CATEGORIES' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
          >
            সাব-ক্যাটাগরি
          </button>
        </div>
      </div>

      {activeTab === 'QUESTIONS' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-gray-700">প্রশ্ন ম্যানেজমেন্ট</h3>
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all font-bold text-sm shadow-md"
            >
              {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {isAdding ? 'বাতিল' : 'নতুন প্রশ্ন'}
            </button>
          </div>

          {isAdding && (
            <form onSubmit={handleSubmitQuestion} className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 space-y-5 animate-in slide-in-from-top-4 duration-300">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1.5">প্রশ্ন</label>
                <textarea
                  required
                  value={formData.questionText}
                  onChange={(e) => setFormData({ ...formData, questionText: e.target.value })}
                  className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none min-h-[100px]"
                  placeholder="প্রশ্নের মূল টেক্সট এখানে লিখুন..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {formData.options.map((opt, idx) => (
                  <div key={idx}>
                    <label className="block text-sm font-bold text-gray-700 mb-1.5">অপশন {String.fromCharCode(65 + idx)}</label>
                    <input
                      type="text"
                      required
                      value={opt}
                      onChange={(e) => {
                        const newOpts = [...formData.options];
                        newOpts[idx] = e.target.value;
                        setFormData({ ...formData, options: newOpts });
                      }}
                      className="w-full p-3.5 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1.5">ক্যাটাগরি</label>
                  <select
                    value={formData.category}
                    onChange={(e) => handleCategoryChange(e.target.value as Category)}
                    className="w-full p-3.5 border rounded-xl outline-none"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1.5">সাব ক্যাটাগরি</label>
                  <select
                    value={formData.subCategory}
                    onChange={(e) => setFormData({ ...formData, subCategory: e.target.value })}
                    className="w-full p-3.5 border rounded-xl outline-none"
                  >
                    {subCategories[formData.category].map(sub => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                    {subCategories[formData.category].length === 0 && (
                      <option disabled>আগে সাব-ক্যাটাগরি তৈরি করুন</option>
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1.5">সঠিক উত্তর</label>
                  <select
                    value={formData.correctAnswerIndex}
                    onChange={(e) => setFormData({ ...formData, correctAnswerIndex: parseInt(e.target.value) })}
                    className="w-full p-3.5 border rounded-xl outline-none"
                  >
                    {formData.options.map((_, idx) => (
                      <option key={idx} value={idx}>অপশন {String.fromCharCode(65 + idx)}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1.5">সাল</label>
                  <input
                    type="text"
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    className="w-full p-3.5 border rounded-xl outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1.5">ব্যাখ্যা (ঐচ্ছিক)</label>
                <textarea
                  value={formData.explanation}
                  onChange={(e) => setFormData({ ...formData, explanation: e.target.value })}
                  className="w-full p-3.5 border rounded-xl outline-none"
                  placeholder="সঠিক উত্তরের বিস্তারিত ব্যাখ্যা দিন..."
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-emerald-600 text-white rounded-xl font-black text-lg flex items-center justify-center gap-2 hover:bg-emerald-700 transition-all shadow-lg"
              >
                <Save className="w-5 h-5" /> প্রশ্নটি সেভ করুন
              </button>
            </form>
          )}

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 text-gray-500 uppercase text-[10px] font-black tracking-widest">
                  <tr>
                    <th className="px-6 py-4">প্রশ্ন</th>
                    <th className="px-6 py-4">ক্যাটাগরি</th>
                    <th className="px-6 py-4">সাব</th>
                    <th className="px-6 py-4">সাল</th>
                    <th className="px-6 py-4 text-center">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {questions.map((q) => (
                    <tr key={q.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 truncate max-w-[200px] font-bold text-gray-700">{q.questionText}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-black">{q.category}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-md text-[10px] font-black">{q.subCategory}</span>
                      </td>
                      <td className="px-6 py-4 text-xs font-bold text-gray-500">{q.year}</td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => onDeleteQuestion(q.id)}
                          className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {questions.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-20 text-center text-gray-400 font-bold">এখনো কোনো প্রশ্ন যুক্ত করা হয়নি।</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'SUB_CATEGORIES' && (
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl">
                <PlusCircle className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black text-gray-800 tracking-tight">নতুন সাব-ক্যাটাগরি যুক্ত করুন</h3>
            </div>
            
            <form onSubmit={handleAddSubCategory} className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1 w-full space-y-1.5">
                <label className="text-xs font-black text-gray-500 uppercase tracking-wider ml-1">ক্যাটাগরি নির্বাচন</label>
                <select 
                  value={newSubCatParent}
                  onChange={(e) => setNewSubCatParent(e.target.value as Category)}
                  className="w-full p-3.5 border rounded-2xl outline-none bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.label}</option>
                  ))}
                </select>
              </div>
              <div className="flex-[2] w-full space-y-1.5">
                <label className="text-xs font-black text-gray-500 uppercase tracking-wider ml-1">নাম</label>
                <input 
                  type="text"
                  required
                  value={newSubCatName}
                  onChange={(e) => setNewSubCatName(e.target.value)}
                  placeholder="যেমন: প্রাচীন সাহিত্য, জ্যামিতি..."
                  className="w-full p-3.5 border rounded-2xl outline-none bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                />
              </div>
              <button 
                type="submit"
                className="w-full md:w-auto px-8 py-3.5 bg-blue-600 text-white rounded-2xl font-black shadow-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" /> যুক্ত করুন
              </button>
            </form>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CATEGORIES.map(cat => (
              <div key={cat.id} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 space-y-4">
                <div className="flex items-center gap-3 pb-4 border-b">
                  <span className="text-2xl">{cat.icon}</span>
                  <h4 className="font-black text-gray-800 tracking-tight">{cat.label}</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {subCategories[cat.id as Category].map(sub => (
                    <div 
                      key={sub}
                      className="group flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-xl text-sm font-bold border border-blue-100 transition-all"
                    >
                      <Tags className="w-3.5 h-3.5" />
                      {sub}
                      <button 
                        onClick={() => onDeleteSubCategory(cat.id as Category, sub)}
                        className="p-1 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                  {subCategories[cat.id as Category].length === 0 && (
                    <p className="text-xs font-bold text-gray-400 py-2 italic">কোনো সাব-ক্যাটাগরি নেই</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
