import React, { useState } from 'react';
import { Question } from '../types';
import { CheckCircle, XCircle, MessageSquare, Sparkles, Bookmark } from 'lucide-react';
import { getAiExplanation } from '../services/geminiService';

interface QuestionItemProps {
  question: Question;
  index: number;
  isBookmarked?: boolean;
  onToggleBookmark?: () => void;
}

const QuestionItem: React.FC<QuestionItemProps> = ({ question, index, isBookmarked, onToggleBookmark }) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleOptionClick = (idx: number) => {
    if (selectedIdx !== null) return;
    setSelectedIdx(idx);
  };

  const handleAiExplain = async () => {
    if (aiExplanation) {
      setShowExplanation(true);
      return;
    }
    setIsAiLoading(true);
    const text = await getAiExplanation(question.questionText, question.options[question.correctAnswerIndex]);
    setAiExplanation(text);
    setShowExplanation(true);
    setIsAiLoading(false);
  };

  const getOptionStyles = (idx: number) => {
    if (selectedIdx === null) {
      return "border-gray-200 hover:border-blue-400 hover:bg-blue-50";
    }
    const isCorrect = idx === question.correctAnswerIndex;
    const isSelected = idx === selectedIdx;

    if (isCorrect) return "border-green-500 bg-green-50 text-green-700 font-bold shadow-sm shadow-green-100";
    if (isSelected && !isCorrect) return "border-red-500 bg-red-50 text-red-700 font-bold shadow-sm shadow-red-100";
    return "border-gray-100 opacity-60";
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-gray-100 shadow-sm transition-all hover:shadow-xl hover:shadow-blue-50/50 group">
      <div className="flex items-start justify-between gap-4 mb-6">
        <div className="flex items-start gap-4">
          <span className="flex-shrink-0 w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-black text-sm">
            {index + 1}
          </span>
          <div>
            <h3 className="text-xl font-bold text-gray-800 leading-snug mb-1">
              {question.questionText}
            </h3>
            <div className="flex gap-2">
              <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">{question.category}</span>
              <span className="text-[10px] font-black uppercase text-blue-500 tracking-widest">• {question.subCategory}</span>
            </div>
          </div>
        </div>
        {onToggleBookmark && (
          <button 
            onClick={onToggleBookmark}
            className={`p-3 rounded-2xl transition-all ${isBookmarked ? 'bg-purple-100 text-purple-600' : 'bg-gray-50 text-gray-300 hover:bg-gray-100 hover:text-gray-400'}`}
          >
            <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 ml-0 md:ml-14">
        {question.options.map((option, idx) => (
          <button
            key={idx}
            disabled={selectedIdx !== null}
            onClick={() => handleOptionClick(idx)}
            className={`p-4 text-left rounded-2xl border transition-all flex items-center justify-between text-base font-medium ${getOptionStyles(idx)}`}
          >
            <span>{String.fromCharCode(65 + idx)}. {option}</span>
            {selectedIdx !== null && idx === question.correctAnswerIndex && <CheckCircle className="w-5 h-5 text-green-600" />}
            {selectedIdx !== null && idx === selectedIdx && idx !== question.correctAnswerIndex && <XCircle className="w-5 h-5 text-red-600" />}
          </button>
        ))}
      </div>

      {selectedIdx !== null && (
        <div className="ml-0 md:ml-14 space-y-4 animate-in fade-in slide-in-from-top-2">
          <div className="flex gap-3">
            <button
              onClick={() => setShowExplanation(!showExplanation)}
              className="flex items-center gap-2 px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-xs font-black hover:bg-gray-200 transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              {showExplanation ? 'ব্যাখ্যা লুপান' : 'ব্যাখ্যা দেখুন'}
            </button>
            <button
              onClick={handleAiExplain}
              disabled={isAiLoading}
              className="flex items-center gap-2 px-5 py-2.5 bg-purple-100 text-purple-700 rounded-xl text-xs font-black hover:bg-purple-200 transition-colors disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              {isAiLoading ? 'AI ভাবছে...' : 'AI ব্যাখ্যা'}
            </button>
          </div>

          {showExplanation && (
            <div className="p-6 bg-blue-50/50 border border-blue-100 rounded-3xl text-sm leading-relaxed shadow-inner">
              <div className="mb-4">
                <p className="text-blue-900 font-black mb-1 uppercase tracking-widest text-[10px]">মূল ব্যাখ্যা</p>
                <p className="text-blue-800 text-base font-medium">{question.explanation}</p>
              </div>
              {aiExplanation && (
                <div className="pt-4 border-t border-blue-200/50">
                  <p className="text-purple-800 font-black mb-1 uppercase tracking-widest text-[10px] flex items-center gap-2">
                    <Sparkles className="w-3 h-3" /> Gemini AI এর বিশ্লেষণ
                  </p>
                  <p className="italic text-gray-700 leading-relaxed text-base">{aiExplanation}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QuestionItem;