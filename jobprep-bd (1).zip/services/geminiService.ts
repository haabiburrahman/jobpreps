
import { GoogleGenAI } from "@google/genai";

// Always use named parameter and direct process.env.API_KEY access
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAiExplanation = async (question: string, answer: string): Promise<string> => {
  // Assume API_KEY is available as per guidelines
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explain simply in Bengali why "${answer}" is the correct answer for the question: "${question}". Keep it concise for a job exam student.`,
    });
    // Correctly accessing the text property from the response
    return response.text || "No explanation generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating AI explanation.";
  }
};
